import java.util.Scanner;
import java.io.*;

public class palindrome {
	public static int main(String[] args) {
		
		String a,b =  "";
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the srting");
		a=s.nextLine();
		int n = a.length ();
		for(int i = n-1; i>=0; i--) {
			b=b+a.charAt(i);
			
		}
		if(a.equalsIgnoreCase(b))
		{
			return 1;
		}
		else {
			return 0;
		}
	}

}
