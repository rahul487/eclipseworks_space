package jan12;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

class Student implements Comparable<Student> {
	int id;
	String name;
	double salary;
	public Student(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	 @Override
	    public int compareTo(Student o) {
	//   	 if(salary==o.salary)
	  // 		 return 0;
	   	// else if(salary<o.salary)
	   		// return -1;
	   	// else
	   	//	 return 1;
		 return name.compareTo(o.name);

	
}
public class TestMain {
	public static void main(String[] args) {
	Student s1 = new Student(101,"Prakash",10000);	
	Student s2 = new Student(102,"Ravi",40000);	
	Student s3 = new Student(103,"Ramesh",140000);
	 ArrayList<Student> al=new ArrayList<>();
   	 al.add(s1);
   	 al.add(s2);
   	 al.add(s3);
   	 Collections.sort(al);
   	 Iterator i=al.iterator();
   	 while(i.hasNext()) {
   		 Student s=(Student) i.next();
   		 System.out.println(s.salary);

	}
	

}






