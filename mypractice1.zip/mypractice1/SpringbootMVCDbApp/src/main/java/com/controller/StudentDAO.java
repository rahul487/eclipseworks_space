package com.controller;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentDAO {
	@Autowired
    StudentRepo srepo;
    //insert a single object
public Student insert(Student s) {
    return srepo.save(s);
}

//Retrieve all the things
public List<Student> getall(){
    return srepo.findAll();
}

//insert a collection of objects
public List<Student> insertall(List<Student> s) {
    return srepo.saveAll(s);
}

//fetch by using an id
public Student getByid(int id) {
    return srepo.findById(id).orElse(null);
}


//delete some thing by id
public String deleteByid(int id) {
    srepo.deleteById(id);
    return "deleted the id value"+ id;
}

//update ->find the value and we save it
//jpaquery
public Student update(Student s) {
   						 
    Student existing=srepo.findById(s.getSid()).orElse(null);
    existing.setName(s.getName());
    return srepo.save(existing);
}


}
