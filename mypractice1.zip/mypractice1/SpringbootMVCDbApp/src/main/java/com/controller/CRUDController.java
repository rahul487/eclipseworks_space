package com.controller;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CRUDController {
	@Autowired
    StudentDAO dao;
    @RequestMapping("insert")
    public ModelAndView insert(@RequestParam("name") String name,@RequestParam("email") String email,HttpServletRequest req,HttpServletResponse res) {
   	 ModelAndView mv=new ModelAndView();
   	 Student ss=new Student();
   	 ss.setName(name);
   	 ss.setEmail(email);
   	 Student sp=dao.insert(ss);
   	 if(sp!=null) {
   		 mv.setViewName("status");
   	 }
   	 return mv;
    }
    
    
    @RequestMapping("getall")
    public ModelAndView get(HttpServletRequest req,HttpServletResponse res) {
   	 ModelAndView mv=new ModelAndView();
   	 List<Student> s=dao.getall();
   	 mv.setViewName("display");
   	 mv.addObject("list",s);
   	 return mv;
    }
}



