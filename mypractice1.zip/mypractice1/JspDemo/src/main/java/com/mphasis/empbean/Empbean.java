package com.mphasis.empbean;

public class Empbean {
	int empno;
    String empname;
    public int getEmpno() {
   	 return empno;
    }
    public void setEmpno(int empno) {
   	 this.empno = empno;
    }
    public String getEmpname() {
   	 return empname;
    }
    public void setEmpname(String empname) {
   	 this.empname = empname;
    }


}
