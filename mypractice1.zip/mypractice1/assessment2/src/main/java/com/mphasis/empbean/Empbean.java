package com.mphasis.empbean;

public class Empbean {
	int cid;
    String classname;
    String actions;
    public int getcid() {
   	 return cid;
    }
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public String getActions() {
		return actions;
	}
	public void setActions(String actions) {
		this.actions = actions;
	}
    

}
