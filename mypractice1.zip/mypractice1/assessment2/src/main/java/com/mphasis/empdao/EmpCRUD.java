package com.mphasis.empdao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mphasis.dbconnection.DbConnection;
import com.mphasis.empbean.Empbean;

public class EmpCRUD {
	  public int insert(Empbean eb) throws ClassNotFoundException, SQLException {
		   	 String sql="insert into classes values(?,?,?)";
		   	 Connection con=DbConnection.dbConn();
		   	 PreparedStatement ps=con.prepareStatement(sql);
		   	 ps.setInt(1,eb.getCid() );
		   	 ps.setString(2,eb.getClassname());
		   	 ps.setString(3,eb.getActions() );
		   	 return ps.executeUpdate();
		   	 
		    }
		    
//		    public ResultSet show() throws ClassNotFoundException, SQLException {
//		   	 Connection con=DbConnection.dbConn();
//		   	 String sql="select * from Employee";
//		   	 PreparedStatement ps=con.prepareStatement(sql);
//		   	 return ps.executeQuery();
//		    }


}
