import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

public class JDBCProgram {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcoperation","root","9482733234Rr");
        System.out.println(con);
        if(con!=null) {
        	System.out.println("connection is established");
        }
        else {
        	System.out.println("check with the connection");
        }
        
           

         
	}
	
}
