package AgeValidator.AgeValidator;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)

public class AgeParameterized {
	int input;
    String output;
    
    public AgeParameterized(int input, String output) {
   	 this.input = input;
   	 this.output = output;
    }

    @Parameterized.Parameters
    public static Collection testDataSet() {
   	 // to convert the series of array into a collection we use Arrays.asList()
   	 return  Arrays.asList(new Object[][] {
   		 {16,"not valid"},{24,"valid age"},{18,"valid age"},
   		 {5,"not valid"}
   		 
   	 });
   	 
    }
    
    

    AgeValidator agevalid;
    @Before
    public void objcreation() {
   	 agevalid=new AgeValidator();
   	 System.out.println("object created");
    }
    
    @Test
    public void test() {
   	 assertEquals(output,agevalid.agevalid(input));
    }
		}


