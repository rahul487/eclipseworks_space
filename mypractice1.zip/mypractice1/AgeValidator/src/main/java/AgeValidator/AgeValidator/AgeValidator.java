package AgeValidator.AgeValidator;

public class AgeValidator {
	public String agevalid(int age) {
	   	 if(age>=18) {
	   		 return "right to vote";
	   	 }
	   	 else {
	   		 return "not valid to vote";
	   	 }
	    }


}
