package com.mphasis.main;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.mphasis.bean.StudentBean;
import com.mphasis.connection.DbConnection;
import com.mphasis.crud.StudentCRUD;


public class StudentMain {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	   	 Scanner sc=new Scanner(System.in);
	   	 while(true) {
	   	 System.out.println("Student CRUD Operations 1.insert student record 2.update student record of name with id  3.delete the record with id  4.retrive all the student records  5.retrive student record with an id  6.exit");
	   	 System.out.println("enter your choice");
	   	 int ch=sc.nextInt();
	   	 switch(ch) {
	   	 case 1:System.out.println("enter the sid value");
	   			 StudentBean sb=new StudentBean();
	   			 sb.setSid(sc.nextInt());
	   			 System.out.println("enter the sname value");
	   			 sb.setSname(sc.next());
	   			 StudentCRUD scrud=new StudentCRUD();
	   			 int rows=scrud.insert(sb);
	   			 if(rows>0) {
	   				 System.out.println("the rows inserted are :"+rows);
	   			 }
	   			 else {
	   				 System.out.println("insertion failed");
	   			 }
	   		 break;
	   	 case 2:
	   		 break;
	   	 case 3:
	   		 break;
	   	 case 4:
	   		 break;
	   	 case 5:
	   		 break;
	   	 case 6:System.exit(0);
	   		 break;
	   	 default:
	   	 }
	   	 
	   	 }
	    }


}
